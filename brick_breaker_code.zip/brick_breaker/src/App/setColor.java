package App;

import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;

/**
 *
 * @author Anna Simankova
 */

public class setColor {
  
    Paint brickColorScheme1=Color.LIME;
    Paint brickColorScheme2=Color.BLUE;
    Paint brickColorScheme3=Color.DEEPPINK;
    Paint brickColorScheme4=Color.MOCCASIN;
  
}
